package org.openjfx.dpeng;

public class GameController {
    
}
